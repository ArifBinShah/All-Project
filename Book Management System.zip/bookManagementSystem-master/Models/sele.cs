﻿namespace Hospital_Management.Models
{
    internal class sele
    {
    }
}